#!/usr/bin/env python3
"""Run a model on BBQ and write the raw responses file the BBQ Tiered Report accepts.

    # any OpenAI-compatible chat endpoint (OpenRouter by default)
    python3 run.py --backend openai --model google/gemma-4-31b-it --trials 5 --temperature 1.0
    python3 run.py --backend openai --base-url http://localhost:8000/v1 --api-key-env NONE --model my-model

    # Claude models through the Anthropic Messages API
    python3 run.py --backend anthropic --model claude-sonnet-5 --trials 5 --temperature 1.0 --disable-thinking

    # your own code (local weights, another SDK): implement generate() in a module
    python3 run.py --backend custom --custom-module custom_example.py --model my-model --concurrency 2

Add --sample 220 for a cheap first run. Output goes to results/<model>_raw.csv;
re-running the same command resumes (rows with status 200 are kept, failed
ones retried). The study's protocol: five trials at temperature 1.0, max_tokens
100, no system prompt; a further temperature-0 run is optional (run again with
--trials 1 --temperature 0 into the same file; the page lets you choose).
"""
import argparse, asyncio, csv, json, os, random, sys, time, importlib.util, re
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from bbq_data import ensure_bbq, validate, CATEGORIES
from prompts import build_all_prompts

FIELDS = ["example_id", "trial", "temperature", "category", "context_condition", "question_polarity", "label_type",
          "stereotyped_groups", "correct_label", "answer_order", "correct_position", "target_position", "unknown_position",
          "prompt", "raw_response", "response_time_ms", "http_status", "error"]
TEMP_OMITTED = -1.0   # recorded when no temperature parameter is sent (the API's default sampling)


def load_env(path: Path):
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def completed_keys(path: Path) -> set:
    done = set()
    if path.exists():
        with open(path, newline="") as f:
            for r in csv.DictReader(f):
                if str(r.get("http_status", "")) == "200":
                    done.add((r["category"], int(r["example_id"]), int(r["trial"]), float(r["temperature"])))
    return done


def append_rows(path: Path, rows: list):
    if not rows:
        return
    new = not path.exists()
    with open(path, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new:
            w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in FIELDS})


# ---------------- backends: each returns {response, status, response_time_ms, error} ----------------
class OpenAIBackend:
    def __init__(self, base_url, model, api_key, max_retries=3):
        import aiohttp
        self.aiohttp = aiohttp; self.url = base_url.rstrip("/") + "/chat/completions"; self.model = model; self.key = api_key; self.retries = max_retries
        self.session = None

    async def start(self):
        self.session = self.aiohttp.ClientSession(timeout=self.aiohttp.ClientTimeout(total=180))

    async def close(self):
        if self.session: await self.session.close()

    async def generate(self, prompt, temperature, max_tokens):
        body = {"model": self.model, "messages": [{"role": "user", "content": prompt}], "max_tokens": max_tokens}
        if temperature is not None:
            body["temperature"] = temperature
        headers = {"Content-Type": "application/json"}
        if self.key:
            headers["Authorization"] = f"Bearer {self.key}"
        for attempt in range(self.retries):
            t0 = time.monotonic()
            try:
                async with self.session.post(self.url, headers=headers, json=body) as resp:
                    ms = int((time.monotonic() - t0) * 1000)
                    if resp.status in (429, 500, 502, 503, 529) and attempt < self.retries - 1:
                        await asyncio.sleep(2 ** attempt); continue
                    try:
                        data = await resp.json(content_type=None)
                    except Exception:
                        data = {"error": {"message": (await resp.text())[:300]}}
                    if resp.status != 200:
                        msg = data.get("error", {}); msg = msg.get("message", str(msg)) if isinstance(msg, dict) else str(msg)
                        return {"response": None, "status": resp.status, "response_time_ms": ms, "error": msg}
                    content = data["choices"][0]["message"]["content"]
                    return {"response": content, "status": 200, "response_time_ms": ms, "error": ""}
            except Exception as e:
                ms = int((time.monotonic() - t0) * 1000)
                if attempt == self.retries - 1:
                    return {"response": None, "status": -1, "response_time_ms": ms, "error": str(e)[:300]}
                await asyncio.sleep(2 ** attempt)
        return {"response": None, "status": -1, "response_time_ms": 0, "error": "exhausted retries"}


class AnthropicBackend:
    def __init__(self, model, api_key, disable_thinking=False, max_retries=4):
        import anthropic
        self.client = anthropic.AsyncAnthropic(api_key=api_key, max_retries=0); self.anthropic = anthropic
        self.model = model; self.disable_thinking = disable_thinking; self.retries = max_retries

    async def start(self): pass
    async def close(self): pass

    async def generate(self, prompt, temperature, max_tokens):
        params = {"model": self.model, "max_tokens": max_tokens, "messages": [{"role": "user", "content": prompt}]}
        if temperature is not None:
            params["temperature"] = temperature
        if self.disable_thinking:
            params["thinking"] = {"type": "disabled"}
        for attempt in range(self.retries):
            t0 = time.monotonic()
            try:
                msg = await self.client.messages.create(**params)
                ms = int((time.monotonic() - t0) * 1000)
                text = "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
                return {"response": text, "status": 200, "response_time_ms": ms, "error": ""}
            except self.anthropic.APIStatusError as e:
                ms = int((time.monotonic() - t0) * 1000)
                if e.status_code in (429, 500, 529) and attempt < self.retries - 1:
                    await asyncio.sleep(2 ** attempt); continue
                return {"response": None, "status": e.status_code, "response_time_ms": ms, "error": str(e)[:300]}
            except Exception as e:
                ms = int((time.monotonic() - t0) * 1000)
                if attempt == self.retries - 1:
                    return {"response": None, "status": -1, "response_time_ms": ms, "error": str(e)[:300]}
                await asyncio.sleep(2 ** attempt)
        return {"response": None, "status": -1, "response_time_ms": 0, "error": "exhausted retries"}


class CustomBackend:
    def __init__(self, module_path):
        spec = importlib.util.spec_from_file_location("custom_backend", module_path)
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        if not hasattr(mod, "generate"):
            sys.exit(f"{module_path} has no generate(prompt, temperature, max_tokens) function")
        self.fn = mod.generate

    async def start(self): pass
    async def close(self): pass

    async def generate(self, prompt, temperature, max_tokens):
        t0 = time.monotonic()
        try:
            text = await asyncio.to_thread(self.fn, prompt, temperature, max_tokens)
            return {"response": "" if text is None else str(text), "status": 200, "response_time_ms": int((time.monotonic() - t0) * 1000), "error": ""}
        except Exception as e:
            return {"response": None, "status": -1, "response_time_ms": int((time.monotonic() - t0) * 1000), "error": str(e)[:300]}


def sample_prompts(prompts, n, seed=42):
    """A stratified sample: equal numbers per category, half ambiguous and half
    disambiguated, both polarities, so even a small run exercises every tier."""
    rng = random.Random(seed); out = []
    per_cat = max(2, n // len(CATEGORIES))
    for c in CATEGORIES:
        for cond in ("ambig", "disambig"):
            pool = [p for p in prompts if p["category"] == c and p["context_condition"] == cond]
            rng.shuffle(pool); out.extend(pool[:max(1, per_cat // 2)])
    return out


async def main_async(a):
    bbq = ensure_bbq(a.bbq_dir); validate(bbq)
    prompts = build_all_prompts(bbq, a.categories)
    if a.sample:
        prompts = sample_prompts(prompts, a.sample)
    temp = None if str(a.temperature).lower() == "none" else float(a.temperature)
    rec_temp = TEMP_OMITTED if temp is None else temp
    jobs = [{**p, "trial": t, "temperature": rec_temp} for p in prompts for t in range(a.trials)]
    out = Path(a.out) if a.out else HERE / "results" / (re.sub(r"[^A-Za-z0-9._-]+", "_", a.model) + "_raw.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    done = completed_keys(out)
    todo = [j for j in jobs if (j["category"], j["example_id"], j["trial"], j["temperature"]) not in done]
    print(f"{len(prompts)} prompts x {a.trials} trial(s) = {len(jobs)} requests; {len(done)} already done; {len(todo)} to run -> {out}", flush=True)
    if not todo:
        return
    if a.backend == "openai":
        load_env(HERE / ".env"); key = None if a.api_key_env.upper() == "NONE" else os.environ.get(a.api_key_env)
        if a.api_key_env.upper() != "NONE" and not key:
            sys.exit(f"{a.api_key_env} is not set (export it, or put it in {HERE / '.env'}); use --api-key-env NONE for a keyless local server")
        be = OpenAIBackend(a.base_url, a.model, key)
    elif a.backend == "anthropic":
        load_env(HERE / ".env"); key = os.environ.get(a.api_key_env if a.api_key_env != "OPENROUTER_API_KEY" else "ANTHROPIC_API_KEY")
        if not key:
            sys.exit("ANTHROPIC_API_KEY is not set")
        be = AnthropicBackend(a.model, key, disable_thinking=a.disable_thinking)
    else:
        if not a.custom_module:
            sys.exit("--backend custom needs --custom-module path/to/module.py")
        be = CustomBackend(a.custom_module)
    await be.start()
    sem = asyncio.Semaphore(a.concurrency); lock = asyncio.Lock(); buf = []; n_done = 0; n_err = 0; t0 = time.monotonic()
    streak = 0; ABORT_AFTER = 25   # consecutive failures: almost always a bad key, model id, or endpoint
    class Abort(Exception): pass

    async def one(job):
        nonlocal n_done, n_err, streak
        async with sem:
            res = await be.generate(job["prompt"], temp, a.max_tokens)
        row = {**job, "raw_response": res["response"], "response_time_ms": res["response_time_ms"], "http_status": res["status"], "error": res.get("error", "")}
        async with lock:
            buf.append(row); n_done += 1; n_err += res["status"] != 200
            streak = streak + 1 if res["status"] != 200 else 0
            if streak >= ABORT_AFTER:
                raise Abort(f"{streak} consecutive failures, last: status {res['status']} {res.get('error', '')[:200]}")
            if len(buf) >= a.checkpoint_every:
                append_rows(out, buf); buf.clear()
                rate = n_done / max(1e-9, time.monotonic() - t0); eta = (len(todo) - n_done) / rate if rate else 0
                print(f"  {n_done}/{len(todo)} ({rate:.1f}/s, {n_err} errors, ETA {eta / 60:.1f} min)", flush=True)
    aborted = None
    try:
        chunk = max(a.concurrency * 10, 1)
        for i in range(0, len(todo), chunk):
            await asyncio.gather(*(one(j) for j in todo[i:i + chunk]))
    except Abort as e:
        aborted = str(e)
    finally:
        append_rows(out, buf); buf.clear(); await be.close()
    if aborted:
        sys.exit(f"stopped: {aborted}. Fix the key, model id, or endpoint and re-run; completed rows are kept.")
    print(f"done: {n_done} requests, {n_err} errors, {time.monotonic() - t0:.0f}s. Upload {out} on the report page ('Add your model').", flush=True)
    if n_err:
        print("re-run the same command to retry the failed rows.", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--backend", choices=["openai", "anthropic", "custom"], required=True)
    ap.add_argument("--model", required=True, help="model id sent to the API, or a name for a custom backend")
    ap.add_argument("--base-url", default="https://openrouter.ai/api/v1", help="OpenAI-compatible base URL (openai backend)")
    ap.add_argument("--api-key-env", default="OPENROUTER_API_KEY", help="environment variable holding the key; NONE for keyless local servers")
    ap.add_argument("--custom-module", help="Python file defining generate(prompt, temperature, max_tokens) -> str")
    ap.add_argument("--trials", type=int, default=5)
    ap.add_argument("--temperature", default="1.0", help="sampling temperature, or 'none' to omit the parameter")
    ap.add_argument("--max-tokens", type=int, default=100)
    ap.add_argument("--concurrency", type=int, default=None, help="parallel requests (default 30 for APIs, 2 for custom)")
    ap.add_argument("--categories", nargs="*", help="run only these BBQ categories")
    ap.add_argument("--sample", type=int, help="stratified sample of about this many examples for a cheap first run")
    ap.add_argument("--disable-thinking", action="store_true", help="anthropic backend: send thinking={type: disabled}")
    ap.add_argument("--checkpoint-every", type=int, default=500)
    ap.add_argument("--bbq-dir", default=str(HERE / "bbq"))
    ap.add_argument("--out", help="output CSV (default results/<model>_raw.csv)")
    a = ap.parse_args()
    if a.concurrency is None:
        a.concurrency = 2 if a.backend == "custom" else 30
    if a.categories:
        bad = [c for c in a.categories if c not in CATEGORIES]
        if bad: sys.exit(f"unknown categories {bad}; choose from {CATEGORIES}")
    asyncio.run(main_async(a))


if __name__ == "__main__":
    main()
