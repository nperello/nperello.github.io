# BBQ runner for the Tiered Report

Run any model on BBQ and get a results file the report page accepts through
"Add your model". This is the study's own generation pipeline, trimmed to
one folder: the same BBQ commit, the same prompt (a single user message, no
system prompt, three answers shuffled deterministically per example), and
the same output columns.

## Install

Python 3.10 or newer.

```bash
pip install -r requirements.txt      # aiohttp; anthropic only for Claude models
```

BBQ itself (Parrish et al., 2022, CC BY 4.0) is fetched on first run into
`bbq/`, pinned to the commit the study used.

## Run

Pick a backend.

**Any OpenAI-compatible chat endpoint.** OpenRouter is the default; set the
base URL for OpenAI, Together, vLLM, Ollama, or anything else that speaks
`/chat/completions`.

```bash
export OPENROUTER_API_KEY=...        # or put it in a .env file next to run.py
python3 run.py --backend openai --model google/gemma-4-31b-it --trials 5 --temperature 1.0

python3 run.py --backend openai --base-url http://localhost:8000/v1 --api-key-env NONE \
    --model my-local-model --trials 5 --temperature 1.0
```

**Claude models**, through the Anthropic Messages API:

```bash
export ANTHROPIC_API_KEY=...
python3 run.py --backend anthropic --model claude-sonnet-5 --trials 5 --temperature 1.0 --disable-thinking
```

Models that reject the temperature parameter take `--temperature none`; the
file then records `-1.0`, the study's sentinel for the API's default
sampling. `--disable-thinking` matches the study's setting for models with
adaptive thinking, whose thinking block would otherwise consume the 100-token
budget.

**Your own code.** Copy `custom_example.py`, implement `generate(prompt,
temperature, max_tokens) -> str` for local weights or another SDK, and:

```bash
python3 run.py --backend custom --custom-module my_model.py --model my-model --concurrency 2
```

## A cheap first run

```bash
python3 run.py --backend openai --model google/gemma-4-31b-it --sample 220 --trials 1
```

runs a stratified sample of about 220 examples, enough to check the key,
the endpoint, and the upload. The report will be noisy and most groups
will be flagged "small n", as it should be.

## The full protocol

The study ran every model on all 58,492 examples, five trials at
temperature 1.0, `max_tokens` 100, and pooled the five trials; a further
temperature-0 run was held out of every reported rate. That is
`--trials 5 --temperature 1.0`, about 292,000 requests per model. Add the
greedy run with a second command into the same file (`--trials 1
--temperature 0`); the page lets you pick which runs to include.

Runs checkpoint every 500 responses and resume: re-running the same
command keeps rows that succeeded and retries the rest.

## Output

`results/<model>_raw.csv`, one row per request, with the study's columns:

| column | meaning |
|---|---|
| example_id, category, context_condition, question_polarity, label_type | the BBQ example |
| trial, temperature | which run; `-1.0` means no temperature parameter was sent |
| stereotyped_groups, correct_label, answer_order | BBQ metadata and the per-example answer shuffle |
| correct_position, target_position, unknown_position | letters, after the shuffle, of the correct, stereotyped, and "unknown" answers |
| prompt, raw_response | what was sent and what came back, verbatim |
| response_time_ms, http_status, error | request outcome; only status 200 rows are scored |

Upload that file on the report page. Responses are parsed with the study's
extractor; rows whose text yields no letter are excluded from denominators
and counted on the page. Compressing the file (`gzip results/x_raw.csv`)
is fine, the page reads `.gz`.

## What differs from the study's runs

The study routed responses that failed strict parsing to a three-model
judge panel. The page has no judge, so those responses are excluded rather
than adjudicated; the excluded count is shown. Everything else, prompt,
shuffle, decoding settings you choose, and the measures, is the same.
