"""Fetch the BBQ benchmark at the commit the study used, and validate it.

BBQ (Parrish et al., ACL Findings 2022, CC BY 4.0): https://github.com/nyu-mll/BBQ
Uses git when available, otherwise downloads the commit archive.
"""
import io, json, os, shutil, subprocess, sys, urllib.request, zipfile
from pathlib import Path

BBQ_REPO_URL = "https://github.com/nyu-mll/BBQ.git"
BBQ_COMMIT = "bea11bd97d79217245b5871acd247b9d6eb24598"
CATEGORIES = ["Age", "Disability_status", "Gender_identity", "Nationality", "Physical_appearance",
              "Race_ethnicity", "Race_x_SES", "Race_x_gender", "Religion", "SES", "Sexual_orientation"]
EXPECTED_TOTAL = 58492
REQUIRED = ["example_id", "question_index", "question_polarity", "context_condition", "category",
            "answer_info", "additional_metadata", "context", "question", "ans0", "ans1", "ans2", "label"]


def ensure_bbq(bbq_dir: Path) -> Path:
    """Make sure bbq_dir holds the BBQ repo at the pinned commit; return it."""
    bbq_dir = Path(bbq_dir)
    if (bbq_dir / "data").is_dir() and (bbq_dir / "analysis_scripts" / "additional_metadata.csv").exists():
        return bbq_dir
    if bbq_dir.exists():
        shutil.rmtree(bbq_dir)
    if shutil.which("git"):
        print(f"cloning BBQ at {BBQ_COMMIT[:12]} into {bbq_dir} ...", flush=True)
        subprocess.run(["git", "clone", "--quiet", BBQ_REPO_URL, str(bbq_dir)], check=True)
        subprocess.run(["git", "-C", str(bbq_dir), "checkout", "--quiet", BBQ_COMMIT], check=True)
    else:
        url = f"https://github.com/nyu-mll/BBQ/archive/{BBQ_COMMIT}.zip"
        print(f"git not found; downloading {url} ...", flush=True)
        data = urllib.request.urlopen(url, timeout=120).read()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            root = z.namelist()[0].split("/")[0]
            z.extractall(bbq_dir.parent)
        os.rename(bbq_dir.parent / root, bbq_dir)
    return bbq_dir


def validate(bbq_dir: Path) -> int:
    total = 0
    for c in CATEGORIES:
        p = Path(bbq_dir) / "data" / f"{c}.jsonl"
        if not p.exists():
            sys.exit(f"missing {p}")
        n = 0
        with open(p) as f:
            for i, line in enumerate(f, 1):
                ex = json.loads(line)
                missing = [k for k in REQUIRED if k not in ex]
                if missing:
                    sys.exit(f"{p}:{i} missing fields {missing}")
                n += 1
        total += n
    if total != EXPECTED_TOTAL:
        print(f"warning: {total} examples, expected {EXPECTED_TOTAL}", file=sys.stderr)
    return total


if __name__ == "__main__":
    d = ensure_bbq(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "bbq")
    print("BBQ at", d, "with", validate(d), "examples")
