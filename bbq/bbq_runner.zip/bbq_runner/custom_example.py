"""Template for `run.py --backend custom --custom-module custom_example.py`.

Implement generate(). It receives one prompt (a single user message; the
study used no system prompt) and must return the model's text. It is called
from a thread pool, --concurrency threads at a time, so it must be safe to
call concurrently (or run with --concurrency 1).

The example below sketches a Hugging Face transformers chat model. Anything
that turns a string into a string works: a local server, a notebook model,
a different SDK.
"""


def generate(prompt: str, temperature, max_tokens: int) -> str:
    # temperature is a float, or None when the run omits the parameter
    # (--temperature none, recorded as -1.0 in the output).
    raise NotImplementedError("implement generate() for your model")

    # --- transformers sketch (uncomment and adapt) ---
    # from transformers import pipeline
    # global _pipe
    # try: _pipe
    # except NameError:
    #     _pipe = pipeline("text-generation", model="your-org/your-model", device_map="auto")
    # out = _pipe([{"role": "user", "content": prompt}], max_new_tokens=max_tokens,
    #             do_sample=temperature not in (None, 0), temperature=temperature or None,
    #             return_full_text=False)
    # return out[0]["generated_text"]
